package ProductList;

import entity.Product;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.cell.TextFieldListCell;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class ProductListController implements Initializable {

    @FXML
    private ListView<Product> productList;

    private EntityManagerFactory emf;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Создание EntityManagerFactory
        emf = Persistence.createEntityManagerFactory("FXlibrarybasePU");
        // Загрузка и отображение продуктов
        loadAndDisplayProducts();
    }

    private void loadAndDisplayProducts() {
        // Создание EntityManager
        EntityManager em = emf.createEntityManager();
        try {
            // Создание запроса для выборки всех продуктов из базы данных
            TypedQuery<Product> query = em.createQuery("SELECT p FROM Product p", Product.class);
            // Получение списка продуктов
            List<Product> products = query.getResultList();
            // Отображение продуктов в ListView
            productList.getItems().addAll(products);
            // Установка ячейки для отображения
            productList.setCellFactory(param -> new TextFieldListCell<Product>() {
                @Override
                public void updateItem(Product item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty || item == null) {
                        setText(null);
                    } else {
                        setText(item.getTitle() + " - Цена: " + item.getPrice() + ", Количество: " + item.getAmount());
                    }
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            // Закрытие EntityManager
            em.close();
        }
    }
}
