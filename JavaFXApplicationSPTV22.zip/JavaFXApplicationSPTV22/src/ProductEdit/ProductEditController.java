package ProductEdit;

import entity.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class ProductEditController {

    @FXML
    private ListView<Product> ViewListProduct;

    @FXML
    private TextField FldNewQuantity;

    @FXML
    private TextField FldNewPrice;

    @FXML
    private Button btEditProduct;

    private ObservableList<Product> productList = FXCollections.observableArrayList();

    @FXML
    void initialize() {
        loadProductList();
    }

    private void loadProductList() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FXlibrarybasePU");
        EntityManager em = emf.createEntityManager();

        List<Product> products = em.createQuery("SELECT p FROM Product p", Product.class).getResultList();
        productList.addAll(products);
        ViewListProduct.setItems(productList);

        em.close();
        emf.close();
    }

    @FXML
    void clickEditProduct(ActionEvent event) {
        Product selectedProduct = ViewListProduct.getSelectionModel().getSelectedItem();
        if (selectedProduct == null) {
            showAlert("Пожалуйста, выберите продукт для редактирования.");
            return;
        }

        String newQuantityStr = FldNewQuantity.getText();
        String newPriceStr = FldNewPrice.getText();

        if (newQuantityStr.isEmpty() || newPriceStr.isEmpty()) {
            showAlert("Пожалуйста, введите новое количество и цену.");
            return;
        }

        try {
            Long newQuantity = Long.parseLong(newQuantityStr);
            Double newPrice = Double.parseDouble(newPriceStr);

            selectedProduct.setAmount(newQuantity);
            selectedProduct.setPrice(newPrice);

            EntityManagerFactory emf = Persistence.createEntityManagerFactory("FXlibrarybasePU");
            EntityManager em = emf.createEntityManager();

            em.getTransaction().begin();
            em.merge(selectedProduct);
            em.getTransaction().commit();

            em.close();
            emf.close();

            showAlert("Продукт успешно обновлен в базе данных.");
            closeWindow();
        } catch (NumberFormatException ex) {
            showAlert("Пожалуйста, введите корректное количество и цену.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Сообщение");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) btEditProduct.getScene().getWindow();
        stage.close();
    }
}
