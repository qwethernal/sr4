package menu;

import ProductCreate.ProductCreationController;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

public class MenuScreenController {

    @FXML
    private MenuItem miAddProduct;

    @FXML
    private MenuItem miCheckProducts;

    @FXML
    private MenuItem miLogin;

    @FXML
    private MenuItem miNewUser;
    
    @FXML
    private MenuItem miEditProduct;

    @FXML
    private MenuItem miListUsers;

    @FXML
    private MenuItem miProfile;

    @FXML
    public void addNewProduct() {
        try {
            // Код для открытия окна добавления товара
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ProductCreate/ProductCreation.fxml"));
            Parent root = loader.load();
            ProductCreationController controller = loader.getController();
            Stage stage = new Stage();
            controller.setStage(stage);
            stage.setScene(new Scene(root));
            stage.setTitle("Product Adding");
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void checkProducts(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ProductList/ProductList.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Product List");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void EditProduct(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ProductEdit/ProductEdit.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Product Editing");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void login(ActionEvent event) {
        showAlert("Вход");
    }

    @FXML
    void addNewUser(ActionEvent event) {
        showAlert("Добавить нового пользователя");
    }

    @FXML
    void listUsers(ActionEvent event) {
        showAlert("Просмотреть список пользователей");
    }

    @FXML
    void userProfile(ActionEvent event) {
        showAlert("Профиль пользователя");
    }
    

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Сообщение");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
